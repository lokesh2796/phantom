const passport = require('passport');

const googleStrategy = require('passport-google-oauth2').Strategy;
const config = require('config.json');
const db = require('_helpers/db');
const encrypt = require('_middleware/encryption');
const decrypt = require('_middleware/decryption');

passport.serializeUser(function(user, done) {
    /*
    From the user take just the id (to minimize the cookie size) and just pass the id of the user
    to the done callback
    PS: You dont have to do it like this its just usually done like this
    */
    done(null, user);
});

passport.deserializeUser(function(user, done) {
    /*
    Instead of user this function usually recives the id 
    then you use the id to select the user from the db and pass the user obj to the done callback
    PS: You can later access this data in any routes in: req.user
    */
    done(null, user);
});

passport.use(new googleStrategy({
    clientID: "34242108267-lp9evu76m9d8ecddd86g7t66hhimdru9.apps.googleusercontent.com",
    clientSecret: "ALmlPl1Tz2hxL0o6ZCOcNn5a",
    callbackURL: "http://localhost:4000/google/callback",
    passReqToCallback: true
}, function(request, accessToken, refreshToken, profile, done) {
    let params = {
        email: encrypt(profile.email),
        name: encrypt(profile.displayName),
        picture: encrypt(profile.picture)
    }
    const account = new db.Account(params);
    account.save();
    return done(null, profile);
}))