const express = require('express');
const router = express.Router();
const Joi = require('joi');
const validateRequest = require('_middleware/validate-request');
const authorize = require('_middleware/authorize')
const shopService = require('./shop.service');

// routes
router.post('/createShop', createshopSchema, createshop);

module.exports = router;

function createshopSchema(req, res, next) {
    const schema = Joi.object({
        userId: Joi.string().required(),
        shopName: Joi.string().required(),
        product: Joi.string().required(),
        quantity: Joi.string().required(),
        price: Joi.string().required(),
    });
    validateRequest(req, next, schema);
}

function createshop(req, res, next) {
    shopService.createshop(req.body)
        .then(() => res.json({ message: 'data saved Successful.' }))
        .catch(next);
}