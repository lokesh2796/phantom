const db = require('_helpers/db');
const encrypt = require('_middleware/encryption');
const decrypt = require('_middleware/decryption');
const { ObjectId } = require('mongoose');

module.exports = {
    createshop,
    updateusers
};


async function createshop(params) {

    // create data
    const shop = new db.Shop(params);
    shop.shopName = encrypt(shop.shopName);
    shop.product = encrypt(shop.product);
    shop.quantity = encrypt(shop.quantity);
    shop.price = encrypt(shop.price);
    // save data
    await shop.save();
    // updateusers(shop);
}

async function updateusers(val) {
    const account = await getAccount(val.userId);
    account.shopId = val._id;
    Object.assign(account, account.shopId);
    await account.save();
}

async function getAccount(id) {
    if (!db.isValidId(id)) throw 'Account not found';
    const account = await db.Account.findById(id);
    if (!account) throw 'Account not found';
    return account;
}