﻿const config = require('config.json');
const jwt = require('jsonwebtoken');
const bcrypt = require('bcryptjs');
const crypto = require("crypto");
const sendEmail = require('_helpers/send-email');
const db = require('_helpers/db');
const encrypt = require('_middleware/encryption');
const decrypt = require('_middleware/decryption');
const mongoose = require('mongoose');

module.exports = {
    googleauth,
    getAll,
    getById
};

async function googleauth(req) {
    console.log(req);
    var mail = encrypt(Email);
    const account = await db.Account.findOne({ Email: mail });
    if (!bcrypt.compareSync(Password, account.Password)) {
        throw 'Email or Password is incorrect';
    }
    // authentication successful so generate jwt and refresh tokens
    const jwtToken = generateJwtToken(account);
    // return basic details and tokens
    account.Email = decrypt(account.Email);
    account.Username = decrypt(account.Username);
    account.Name = decrypt(account.Name);
    account.Mobile = decrypt(account.Mobile);
    return {
        ...basicDetails(account),
        jwtToken,
    };
}

async function getAll() {
    const accounts = await db.Account.find();
    return accounts.map(function(x) {
        x.Email = decrypt(x.Email);
        x.Username = decrypt(x.Username);
        x.Name = decrypt(x.Name);
        x.Mobile = decrypt(x.Mobile);
        return basicDetails(x);
    });
}

async function getById(id) {
    const account = await getAccount(id);
    console.log(account.length);
    let decryptdatas = account.map((x) => {
        x.email = decrypt(x.email);
        x.name = decrypt(x.name);
        x.picture = decrypt(x.picture);
        x.shopName = decrypt(x.shopName);
        x.product = decrypt(x.product);
        x.quantity = decrypt(x.quantity);
        x.price = decrypt(x.price);
        x.transactionid = decrypt(x.transactionid);
        x.amount = decrypt(x.amount);
    })
    console.log(decryptdatas);
    // account.email = decrypt(account.email);
    // account.name = decrypt(account.name);
    // account.picture = decrypt(account.picture);
    // console.log(account);
    return account;
    // return basicDetails(account);
}

async function getAccount(id) {
    let matchObj = {};
    if (id) {
        matchObj['_id'] = mongoose.Types.ObjectId(id);
    }
    if (!db.isValidId(id)) throw 'Account not found';
    const account = await db.Account.aggregate([{
            $match: {...matchObj },
        }, {
            $lookup: {
                from: "shops",
                localField: "_id",
                foreignField: "userId",
                as: "purchase_Datas"
            }
        },
        { $unwind: "$purchase_Datas" },
        {
            $lookup: {
                from: "transactions",
                localField: "_id",
                foreignField: "userId",
                as: "transactions"
            }
        },
        { $unwind: "$transactions" },
        {
            $project: {
                email: 1,
                name: 1,
                picture: 1,
                shopName: "$purchase_Datas.shopName",
                product: "$purchase_Datas.product",
                quantity: "$purchase_Datas.quantity",
                price: "$purchase_Datas.price",
                transactionid: "$transactions.ID",
                amount: "$transactions.Amount",
            }
        }
    ]);
    if (!account) throw 'Account not found';
    return account;
}

function basicDetails(account) {
    const { id, Email, Name, Username, Mobile, created, updated } = account;
    return { id, Email, Name, Username, Mobile, created, updated };
}