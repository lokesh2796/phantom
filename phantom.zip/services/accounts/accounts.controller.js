﻿const express = require('express');
const router = express.Router();
const Joi = require('joi');
const validateRequest = require('_middleware/validate-request');
const authorize = require('_middleware/authorize')
const accountService = require('./account.service');

// routes
router.get('/', authorize(), getAll);
router.post('/auth', googleauthSchema, googleauth);
router.get('/:id', getById);
module.exports = router;

function googleauthSchema(req, res, next) {
    const schema = Joi.object({
        Email: Joi.string().required(),
        name: Joi.string().required()
    });
    validateRequest(req, next, schema);
}

function googleauth(req, res, next) {
    accountService.googleauth(req.body)
        .then(({...account }) => {
            res.json(account);
        })
        .catch(next);
}

function getAll(req, res, next) {
    accountService.getAll()
        .then(accounts => res.json(accounts))
        .catch(next);
}


function getById(req, res, next) {
    // if (req.params.id !== req.user.id) {
    //     return res.status(401).json({ message: 'Unauthorized' });
    // }

    accountService.getById(req.params.id)
        .then(account => account ? res.json(account) : res.sendStatus(404))
        .catch(next);
}