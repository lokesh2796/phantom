const db = require('_helpers/db');
const encrypt = require('_middleware/encryption');
const decrypt = require('_middleware/decryption');
const { ObjectId } = require('mongoose');

module.exports = {
    createTransaction,
    deletealltransactions,
    // updateusers
};


async function createTransaction(params) {
    var transactionid = encrypt(params.ID);
    // validate
    if (await db.Transaction.findOne({ ID: transactionid })) {
        // send already registered error in Email to prevent transaction enumeration
        throw 'Transaction Already completed with this Transaction Id.';
    }

    // create transaction object
    const transaction = new db.Transaction(params);
    transaction.ID = encrypt(transaction.ID);
    transaction.Amount = encrypt(transaction.Amount);
    // save transaction
    await transaction.save();
    // updateusers(transaction);
}

async function deletealltransactions(id) {
    await db.Transaction.remove();
}

async function updateusers(val) {
    const account = await getAccount(val.userId);
    account.shopId = val._id;
    Object.assign(account, account.shopId);
    await account.save();
}

async function getAccount(id) {
    if (!db.isValidId(id)) throw 'Account not found';
    const account = await db.Account.findById(id);
    if (!account) throw 'Account not found';
    return account;
}