const express = require('express');
const router = express.Router();
const Joi = require('joi');
const validateRequest = require('_middleware/validate-request');
const authorize = require('_middleware/authorize')
const transactionService = require('./transaction.service');

// routes
router.post('/createTransaction', createTransactionSchema, createTransaction);
router.delete('/:id', authorize(), _delete);

module.exports = router;

function createTransactionSchema(req, res, next) {
    const schema = Joi.object({
        ID: Joi.string().required(),
        userId: Joi.string().required(),
        shopId: Joi.string().required(),
        Amount: Joi.string().required(),
    });
    validateRequest(req, next, schema);
}

function createTransaction(req, res, next) {
    transactionService.createTransaction(req.body)
        .then(() => res.json({ message: 'Transaction Successful.' }))
        .catch(next);
}

function _delete(req, res, next) {
    transactionService.deletealltransactions()
        .then(transactions => res.json(transactions))
        .catch(next);
}