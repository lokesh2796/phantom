﻿require('rootpath')();
const express = require('express');
const app = express();
const bodyParser = require('body-parser');
const cookieParser = require('cookie-parser');
const cors = require('cors');
const cookieSession = require('cookie-session')
const errorHandler = require('_middleware/error-handler');
const passport = require('passport');
const config = require('config.json');
require('./_middleware/passport-setup');
var Razorpay = require("razorpay");
app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());
app.use(cookieParser());

const encrypt = require('_middleware/encryption');
const decrypt = require('_middleware/decryption');
const { func } = require('joi');
// allow cors requests from any origin and with credentials
app.use(cors({ origin: (origin, callback) => callback(null, true), credentials: true }));
let instance = new Razorpay({
    key_id: config.razopay_key, // your `KEY_ID`
    key_secret: config.razorpay_secret // your `KEY_SECRET`
})
app.use(cookieSession({
    name: 'tuto-session',
    keys: ['key1', 'key2']
}))
app.set('view engine', 'ejs');
app.use(passport.initialize());
app.use(passport.session());
// api routes
app.use('/accounts', require('./services/accounts/accounts.controller'));
app.use('/transactions', require('./services/transactions/transactions.controller'));
app.use('/shops', require('./services/shops/shops.controller'));
// Auth middleware that checks if the user is logged in
const isLoggedIn = (req, res, next) => {
    if (req.user) {
        next();
    } else {
        res.sendStatus(401);
    }
}

app.post("/payment/order", (req, res) => {
    params = req.body;
    instance.orders.create(params).then((data) => {
        res.send({ "order_details": data, "status": "success" });
    }).catch((error) => {
        res.send({ "order_details": error, "status": "failed" });
    })
});




app.post("/payment/verify", (req, res) => {
    body = req.body.razorpay_order_id + "|" + req.body.razorpay_payment_id;
    var crypto = require("crypto");
    var expectedSignature = crypto.createHmac('sha256', 'NUj8iaNb8vqW31piABdVmqjO')
        .update(body.toString())
        .digest('hex');
    console.log("sig" + req.body.razorpay_signature);
    console.log("sig" + expectedSignature);
    var response = { "status": "failure" }
    if (expectedSignature === req.body.razorpay_signature)
        response = { "status": "success" }
    res.send(response);
});


app.get('/', (req, res) => {
    res.render('pages/index');
})

function getincreament(val) {
    if (val) {
        return ++val;
    } else {
        throw "val must be defined";
    }
}

async function handler(req, res) {
    let response;
    console.log('hello there');
    response = await getincreament(3);
    console.log(response);
    let [data1, data2, data3] = await Promise.all([
        getincreament(2),
        getincreament(4),
        getincreament(6)
    ])
    console.log(data1);
    console.log(data2);
    console.log(data3);
    res.send('async functions executed');
}

app.get('/success', isLoggedIn, (req, res) => {
    // let req1 = { name: req.user.displayName, email: req.user.email, pic: req.user.picture };
    // app.post('/accounts/auth', (req1, res) => {
    res.render('pages/profile', { name: req.user.displayName, email: req.user.email, pic: req.user.picture });
    // })
})

app.get('/checkasync', handler);


app.get('/encrypt/:id', (req, res) => {
    let val = encrypt(req.params.id);
    res.send(val);
})

app.get('/decrypt/:id', (req, res) => {
    let val = decrypt(req.params.id);
    res.send(val);
})

app.get('/google', passport.authenticate('google', { scope: ['email', 'profile'] }));

app.get('/google/callback', passport.authenticate('google', { failureRedirect: '/failed' }),
    function(req, res) {
        // Successful authentication, redirect home.
        res.redirect('/success');
    }
);

app.get('/logout', (req, res) => {
    req.session = null;
    req.logout();
    res.redirect('/');
})

// global error handler
app.use(errorHandler);

// start server
const port = process.env.NODE_ENV === 'production' ? (process.env.PORT || 80) : 4000;
app.listen(port, () => {
    console.log('Server listening on port ' + port);
});